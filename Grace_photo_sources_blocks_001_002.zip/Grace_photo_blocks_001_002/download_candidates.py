#!/usr/bin/env python3
"""Fetch researched Grace Cosmetics image candidates. Never updates a live catalogue."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import time
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen

from PIL import Image, ImageChops, ImageOps, ImageDraw

Image.MAX_IMAGE_PIXELS = 40_000_000
MAX_DOWNLOAD = 25 * 1024 * 1024
AGENT = "GraceCatalogImageFetcher/1.0"
BAD_IMAGE_WORDS = ("placeholder", "default_image", "no-image", "no_image", "spacer.gif")
SAFE_ID = re.compile(r"GC[0-9]+$")


def read_http(url: str, *, referer: str = "", limit: int = MAX_DOWNLOAD) -> bytes:
    """HTTP(S) only, finite timeout and payload size; does not bypass access restrictions."""
    parts = urlsplit(url)
    if parts.scheme not in ("https", "http") or not parts.hostname:
        raise ValueError("Invalid HTTP(S) URL")
    headers = {"User-Agent": AGENT, "Accept": "*/*"}
    if referer:
        headers["Referer"] = referer
    request = Request(url, headers=headers)
    with urlopen(request, timeout=25) as response:
        if urlsplit(response.url).scheme not in ("https", "http"):
            raise ValueError("Unsupported redirect")
        content = response.read(limit + 1)
    if len(content) > limit:
        raise ValueError("Response exceeds size limit")
    return content


class ProductMetadata(HTMLParser):
    """Only Product JSON-LD / page-level OG metadata; never scans arbitrary gallery thumbnails."""
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.og: list[str] = []
        self.ld: list[str] = []
        self._inside = False
        self._buffer: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = {k.lower(): v or "" for k, v in attrs}
        if tag == "meta" and a.get("property", a.get("name", "")).lower() in (
            "og:image", "og:image:secure_url"
        ):
            if a.get("content"):
                self.og.append(a["content"])
        if tag == "script" and a.get("type", "").lower() == "application/ld+json":
            self._inside = True
            self._buffer = []

    def handle_data(self, data: str) -> None:
        if self._inside:
            self._buffer.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._inside:
            self.ld.append("".join(self._buffer))
            self._inside = False


def product_nodes(value: Any) -> list[dict[str, Any]]:
    """Follow only document/main-entity containers, not related-product recommendation lists."""
    if isinstance(value, list):
        return [p for v in value for p in product_nodes(v)]
    if not isinstance(value, dict):
        return []
    kind = value.get("@type", [])
    kinds = [kind] if isinstance(kind, str) else kind
    if "Product" in kinds:
        return [value]
    found: list[dict[str, Any]] = []
    for key in ("@graph", "mainEntity"):
        if key in value:
            found += product_nodes(value[key])
    return found


def image_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [u for v in value for u in image_strings(v)]
    if isinstance(value, dict):
        return image_strings(value.get("contentUrl") or value.get("url") or [])
    return []


def extract_candidates(html: str, page_url: str) -> list[tuple[str, str]]:
    p = ProductMetadata()
    p.feed(html)
    nodes: list[dict[str, Any]] = []
    for block in p.ld:
        try:
            nodes += product_nodes(json.loads(block))
        except (ValueError, TypeError):
            continue
    urls: list[tuple[str, str]] = []
    # Ambiguous JSON-LD products are not automatically matched to a catalogue row.
    if len(nodes) == 1:
        urls += [(u, "product_json_ld") for u in image_strings(nodes[0].get("image"))]
    urls += [(u, "og_image_needs_visual_review") for u in p.og]
    output: list[tuple[str, str]] = []
    seen: set[str] = set()
    for url, method in urls:
        absolute = urljoin(page_url, url)
        if absolute not in seen and urlsplit(absolute).scheme in ("http", "https"):
            if not any(word in absolute.lower() for word in BAD_IMAGE_WORDS):
                output.append((absolute, method))
                seen.add(absolute)
    return output


def normalize_candidate(data: bytes, target: dict[str, Any]) -> tuple[Image.Image | None, dict[str, Any]]:
    """Conservative white-margin crop; no recolouring, AI retouch, stretching or upscaling."""
    with Image.open(io.BytesIO(data)) as src:
        if getattr(src, "n_frames", 1) != 1:
            return None, {"status": "review_animated_image"}
        original_format = src.format or "UNKNOWN"
        icc_present = bool(src.info.get("icc_profile"))
        rgba = ImageOps.exif_transpose(src).convert("RGBA")
    white = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    rgb = Image.alpha_composite(white, rgba).convert("RGB")
    w, h = rgb.size
    report: dict[str, Any] = {
        "input_width": w, "input_height": h, "input_format": original_format,
        "icc_profile_present": icc_present,
        "approved_for_import": False,
    }
    # Embedded nontrivial profiles require controlled colour management outside this draft script.
    if icc_present:
        return None, {**report, "status": "review_colour_profile"}
    if min(w, h) < 32:
        return None, {**report, "status": "reject_tiny_image"}

    step = max(1, min(w, h) // 100)
    border = ([rgb.getpixel((x, 0)) for x in range(0, w, step)] +
              [rgb.getpixel((x, h - 1)) for x in range(0, w, step)] +
              [rgb.getpixel((0, y)) for y in range(0, h, step)] +
              [rgb.getpixel((w - 1, y)) for y in range(0, h, step)])
    white_ratio = sum(min(px) >= 250 for px in border) / len(border)
    report["near_white_border_fraction"] = round(white_ratio, 4)
    if white_ratio < 0.98:
        return None, {**report, "status": "review_background_or_edge_crop"}

    # Zeroing only almost-white margins is NOT reliable segmentation; output always stays a draft.
    diff = ImageChops.difference(rgb, Image.new("RGB", rgb.size, "white"))
    channels = diff.split()
    magnitude = ImageChops.lighter(ImageChops.lighter(channels[0], channels[1]), channels[2])
    bbox = magnitude.point(lambda p: 255 if p > 5 else 0).getbbox()
    if not bbox:
        return None, {**report, "status": "reject_blank_image"}
    left, top, right, bottom = bbox
    if left <= 1 or top <= 1 or right >= w - 1 or bottom >= h - 1:
        return None, {**report, "status": "review_object_touches_edge"}
    report["estimated_foreground_bbox"] = list(bbox)
    # Keep a small buffer to avoid trimming very pale packaging edges.
    padding = 3
    box = (max(0, left-padding), max(0, top-padding), min(w, right+padding), min(h, bottom+padding))
    cropped = rgb.crop(box)
    object_target = int(target["product_max_side_px"])
    if max(cropped.size) < object_target:
        return None, {**report, "status": "review_insufficient_native_resolution",
                      "estimated_object_max_side": max(cropped.size)}
    scale = object_target / max(cropped.size)
    size = (max(1, round(cropped.width*scale)), max(1, round(cropped.height*scale)))
    resized = cropped.resize(size, Image.Resampling.LANCZOS)
    canvas_px = int(target["canvas_px"])
    canvas = Image.new("RGB", (canvas_px, canvas_px), "white")
    canvas.paste(resized, ((canvas_px-size[0])//2, (canvas_px-size[1])//2))
    return canvas, {**report, "status": "draft_needs_visual_and_rights_review",
                    "output_width": canvas_px, "output_height": canvas_px}


def atomic_json(path: Path, value: Any) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def run(args: argparse.Namespace) -> None:
    source = json.loads(args.manifest.read_text(encoding="utf-8"))
    destination = args.output
    destination.mkdir(parents=True, exist_ok=True)
    report_path = destination / "download_report.json"
    report = json.loads(report_path.read_text()) if report_path.exists() else {}
    identity = hashlib.sha256(args.manifest.read_bytes()).hexdigest()

    for row in source["products"]:
        pid = row["mig_id"]
        if not SAFE_ID.fullmatch(pid):
            raise ValueError(f"Unsafe product key: {pid!r}")
        previous = report.get(pid, {})
        if (not args.retry and previous.get("manifest_sha256") == identity
                and previous.get("original_file") and Path(previous["original_file"]).exists()):
            print(pid, "already downloaded; see report")
            continue
        entry: dict[str, Any] = {
            "mig_id": pid, "name": row["original_name"], "manifest_sha256": identity,
            "approved_for_import": False, "errors": [],
        }
        if not row.get("download_allowed"):
            report[pid] = {**entry, "status": "held_identity_not_confirmed"}
            atomic_json(report_path, report)
            continue
        candidates: list[tuple[str, str]] = []
        if row.get("image_url"):
            candidates.append((row["image_url"], "researched_direct_url"))
        pages = [row["source_page"]] + row.get("alternate_source_pages", [])
        # Only inspect pre-researched product pages. No broad web search, no model/API calls.
        for page in pages:
            try:
                html = read_http(page, limit=8*1024*1024).decode("utf-8", errors="replace")
                candidates += extract_candidates(html, page)
            except Exception as exc:
                entry["errors"].append({"page": page, "error": str(exc)})
            time.sleep(0.3)

        seen: set[str] = set()
        attempts: list[dict[str, Any]] = []
        first_saved = None
        draft_saved = False
        for url, method in candidates:
            if url in seen:
                continue
            seen.add(url)
            if len(seen) > 4:
                break
            if any(word in url.lower() for word in BAD_IMAGE_WORDS):
                continue
            try:
                data = read_http(url, referer=row["source_page"])
                # Validate actual file bytes, not its extension or Content-Type.
                with Image.open(io.BytesIO(data)) as check:
                    fmt = check.format
                    check.verify()
                if fmt not in ("JPEG", "PNG", "WEBP"):
                    raise ValueError(f"Unsupported raster format: {fmt}")
                original_dir = destination / f"block_{int(row['block']):03d}" / "originals"
                draft_dir = original_dir.parent / "drafts"
                original_dir.mkdir(parents=True, exist_ok=True)
                extension = {"JPEG":".jpg", "PNG":".png", "WEBP":".webp"}[fmt]
                saved = original_dir / f"{pid}_{len(attempts)+1}{extension}"
                saved.write_bytes(data)
                if first_saved is None:
                    first_saved = str(saved.resolve())
                image, details = normalize_candidate(data, source["target"])
                attempt = {**details, "url":url, "extraction_method":method,
                           "original_file":str(saved.resolve()),
                           "sha256":hashlib.sha256(data).hexdigest()}
                if image is not None:
                    draft_dir.mkdir(exist_ok=True)
                    draft = draft_dir / f"{pid}.webp"
                    image.save(draft, "WEBP", quality=int(source["target"]["quality"]), method=6)
                    attempt["draft_file"] = str(draft.resolve())
                    attempt["draft_bytes"] = draft.stat().st_size
                    entry.update(attempt)
                    draft_saved = True
                attempts.append(attempt)
                if draft_saved:
                    break
            except Exception as exc:
                entry["errors"].append({"url":url, "error":str(exc)})
            time.sleep(0.5)

        entry["attempts"] = attempts
        if not draft_saved:
            entry["status"] = "downloaded_but_requires_review" if first_saved else "no_image_downloaded"
            if first_saved:
                entry["original_file"] = first_saved
        report[pid] = entry
        atomic_json(report_path, report)
        print(pid, entry["status"])

    # Contact sheets exist only when images were actually downloaded and normalized.
    for block in sorted({int(r["block"]) for r in source["products"]}):
        rows = [r for r in source["products"] if int(r["block"]) == block]
        if not any(report.get(r["mig_id"], {}).get("draft_file") for r in rows):
            continue
        sheet = Image.new("RGB", (1000, 470), "white")
        draw = ImageDraw.Draw(sheet)
        for index, row in enumerate(rows):
            x, y = (index % 5)*200, (index // 5)*235
            item = report.get(row["mig_id"], {})
            if item.get("draft_file"):
                with Image.open(item["draft_file"]) as image:
                    thumb = ImageOps.contain(image.convert("RGB"), (190, 195))
                    sheet.paste(thumb, (x+(200-thumb.width)//2, y+5))
            draw.text((x+8, y+205), row["mig_id"], fill="black")
            draw.text((x+8, y+220), "DRAFT" if item.get("draft_file") else "NO DRAFT", fill="black")
        sheet.save(destination / f"block_{block:03d}_contact_sheet.jpg", quality=90)

    print("Done. Nothing was imported into the website. Review download_report.json and draft images.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=Path(__file__).with_name("manifest.json"))
    parser.add_argument("--output", type=Path, default=Path("grace_photo_review"))
    parser.add_argument("--retry", action="store_true", help="Retry existing rows; default reuses successful downloads.")
    run(parser.parse_args())
